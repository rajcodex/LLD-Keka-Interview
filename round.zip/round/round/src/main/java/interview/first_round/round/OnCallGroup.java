package interview.first_round.round;

public class OnCallGroup {
    
	private OnCallPerson person;
	public OnCallGroup(OnCallPerson person) {
		super();
		this.person = person;
	}
	public OnCallPerson getPerson() {
		return person;
	}
	public void setPerson(OnCallPerson person) {
		this.person = person;
	}
	

}
