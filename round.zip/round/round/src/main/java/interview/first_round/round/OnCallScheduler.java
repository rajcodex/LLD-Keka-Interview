package interview.first_round.round;

public class OnCallScheduler {

	public OnCallScheduler() {
		// TODO Auto-generated constructor stub
	}

}
