package interview.first_round.round;

public enum Severity {
	CRITICAL,
	ERROR,
	WARNING

}
