package interview.first_round.round;

import java.util.List;

public class CriticalOnCallNotify implements OnCallNotify{
    private String telephony_url;
	public CriticalOnCallNotify() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void notifyAlert(OnCallGroup onCallGroup) {
		// TODO Auto-generated method stub
		OnCallPerson current_on_call= onCallGroup.getPerson();
		makePhoneCall(telephony_url,person);
		
	}
	
	void makePhoneCall(String )

}
