package interview.first_round.round;

import java.util.List;

public class IncidentAlert {
	
	List<OnCallGroup> onCallGroups;
    CriticalOnCallNotify criticalNoficationService;
    WarningOnCallNotify WarningNoficationService;
    ErrorOnCallNotify ErrorNoficationService;


	public IncidentAlert(List<OnCallGroup> onCallGroups, CriticalOnCallNotify criticalNoficationService,
			WarningOnCallNotify warningNoficationService, ErrorOnCallNotify errorNoficationService) {
		super();
		this.onCallGroups = onCallGroups;
		this.criticalNoficationService = criticalNoficationService;
		WarningNoficationService = warningNoficationService;
		ErrorNoficationService = errorNoficationService;
	}

	public void sendNotification(List<Alert> alerts) {
		// TODO Auto-generated method stub
		for(Alert currentAlert : alerts)
		{
			OnCallGroup group = currentAlert.getGroup();
			if(currentAlert.getSeverity().equals("CRITICAL"))
			{
				criticalNoficationService.notifyAlert(group);
			}
			else if(currentAlert.getSeverity().equals("Warning"))
			{
				WarningNoficationService.notifyAlert(group);
			}
			else if(currentAlert.getSeverity().equals("ERROR"))
			{
				ErrorNoficationService.notifyAlert(group);
			}
			}
			
			
		}
		
		
	}

}
