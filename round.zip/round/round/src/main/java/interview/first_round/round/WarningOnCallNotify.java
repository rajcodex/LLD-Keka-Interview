package interview.first_round.round;

import java.util.List;

public class WarningOnCallNotify implements OnCallNotify{

	public WarningOnCallNotify() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void notifyAlert(OnCallGroup group) {
		// TODO Auto-generated method stub
		
	}

}
