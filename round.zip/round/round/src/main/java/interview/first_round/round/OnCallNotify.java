package interview.first_round.round;

import java.util.List;

public interface OnCallNotify {
	
	void notifyAlert(List<OnCallGroup> onCallGroups);

	void notifyAlert(OnCallGroup group);

}
