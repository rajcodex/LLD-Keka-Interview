package interview.first_round.round;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoundApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoundApplication.class, args);
	}

}
