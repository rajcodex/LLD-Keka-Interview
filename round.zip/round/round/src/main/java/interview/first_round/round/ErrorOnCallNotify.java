package interview.first_round.round;

import java.util.List;

public class ErrorOnCallNotify implements OnCallNotify {

	public ErrorOnCallNotify()  {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void notifyAlert(List<OnCallGroup> onCallGroups) {
		// TODO Auto-generated method stub
		
	}

}
