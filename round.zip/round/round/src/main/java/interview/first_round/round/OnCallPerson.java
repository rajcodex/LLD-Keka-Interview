package interview.first_round.round;

public class OnCallPerson {

	public OnCallPerson() {
		// TODO Auto-generated constructor stub
	}

}
