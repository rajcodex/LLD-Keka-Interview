package interview.first_round.round;

public class Alert {
    private String message;
    private String service;
    private OnCallGroup group;
    private Severity severity;
    public Alert(String message, String service, OnCallGroup group, Severity severity) {
		super();
		this.message = message;
		this.service = service;
		this.group = group;
		this.severity = severity;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public OnCallGroup getGroup() {
		return group;
	}

	public void setGroup(OnCallGroup group) {
		this.group = group;
	}

	public Severity getSeverity() {
		return severity;
	}

	public void setSeverity(Severity severity) {
		this.severity = severity;
	}

	

}

	