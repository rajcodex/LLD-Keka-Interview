package interview.first_round.round;

import java.util.List;

public class AlertEmit {
    
	private List<Alert> alerts;
	private IncidentAlert pagerduty;


	public AlertEmit(List<Alert> alerts,IncidentAlert pagerduty) {
		super();
		this.alerts = alerts;
		this.pagerduty=pagerduty;
	}
	
	public void insertAlert(Alert alert)
	{
		alerts.add(alert);
	}
	
	public void emitAlert()
	{
		pagerduty.sendNotification(alerts);
		alerts.clear();
	}
	
	

}
